% Summary of the parameters
m = 0.314;  %   mass of the pendulum
L = 0.64;   %   Length of the rod
d = 0.05;   %   coefficient of viscous friction
g = 9.81;   %   acceleration by gravity
mu = 0.05;  %   coefficient of viscous friction

% Simplified terms
I = (m*L^2)/12;
G = (I + m*L^2); %   The matrix denominator

% The matrix values
a = 0;
b = 1;
c = (m*g*L)/G;
d = -mu/G;

e = m*L/G;
f = (-mu*m*L)/G^2;

% The matrices
A = [a, b; -c, d];
B = [e; f];

PX = 8 *[-1 -1.1];
GAIN_K = place(A,B,PX);

