clear all
close all 
clc
% clean up matlab before launching script
% simulate force controlled pendulum on cart using full non-linear model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Summary of the parameters
m = 0.314;  %   mass of the pendulum
L = 0.64;   %   Length of the rod
d = 0.05;   %   coefficient of viscous friction
g = 9.81;   %   acceleration by gravity
mu = 0.05;  %   coefficient of viscous friction

% Simplified terms
I = (m*L^2)/12;
G = (I + m*L^2); %   The matrix denominator

% The matrix values
a = 0;
b = 1;
c = (m*g*L)/G;
d = -mu/G;

e = m*L/G;
f = (-mu*m*L)/G^2;

% The matrices
A = [a, b; -c, d];
B = [e; f];
C = [1 0];
D = 0;
%-------------------------------------------------------------------
PX = 8 *[-1 -1.1];
GAIN_K = place(A,B,PX);
GAIN_K;

%-----------------------------------------------------------------
%-----------------------------------------------------------------
% time steps of 100ms for integration
timeStep = 0.1;
% total time for simulation
totalTime = 30;
% build timepoint vector
tspan = 0:timeStep:totalTime;


titleMessage = 'uncontrolled nonlinear sim of FC pendulum on cart';
disp(titleMessage)


% initial conditions
% located at x=0
% velocity =0
% angle  pi (inverted)
% angular velocity = 0.5 rads-1
x0 = [0; 2;];

% use ode to solve with FCPendOnCart with no control force input u
% representing a force controlled pendulum on a cart
% model introduces slight amount of noise to wont stay balanced

[y, t, X_OUT] = SFC_INTEGRATION(A, B, C, D, GAIN_K, tspan, x0);

% for all time point animate the results
range=1;
len = length(tspan);
kickFlag = zeros(1,len);

% get variables
x = 0 * y(1, :);    % cart positon
the = y(1,:)
th = transpose(the);   % pendulum angle

% animate pendulum
figure
AnimatePendulumCart(th + pi,  x, L/2, tspan, range, kickFlag, "titleMessage");

