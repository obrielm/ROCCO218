function T5_FUNCTION = TASK_5_FUNC(A, x, B, u )


T5_FUNCTION = A*x + B*u;
end

